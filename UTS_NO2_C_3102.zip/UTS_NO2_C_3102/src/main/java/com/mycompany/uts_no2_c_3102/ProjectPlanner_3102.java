/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3102;

/**
 *
 * @author lenovo
 */
public class ProjectPlanner_3102 extends Employess_3102{
    public float Komisi_3102;
    public float TotalHslProyek_3102;
    public double Totalgaji_3102;
    
    public ProjectPlanner_3102(){
        
    }
            
    public double TotalGaji_3102(){
        Totalgaji_3102 = GajiPokok_3102 + (Komisi_3102 * TotalHslProyek_3102) - (GajiPokok_3102 *5/100);
        return Totalgaji_3102;
    }
    
    public void TampilData_3102(){
        System.out.println("Project Plannner");
        Tampil_3102();
        System.out.println("Total Gaji: " + Totalgaji_3102);
    }
}

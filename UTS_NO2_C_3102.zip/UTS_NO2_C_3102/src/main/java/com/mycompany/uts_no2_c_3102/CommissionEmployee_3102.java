/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3102;

/**
 *
 * @author lenovo
 */
public class CommissionEmployee_3102 extends Employess_3102{
    public float Komisi_3102;
    public float TotalPenjualan_3102;
    public float Totalgaji_3102;
    
    public CommissionEmployee_3102(){
        
    }
    
    public float TotalGaji_3102(){
        Totalgaji_3102 = GajiPokok_3102 + (Komisi_3102 * TotalPenjualan_3102);
        return Totalgaji_3102;
    }
    
    public void TampilData_3102(){
        System.out.println("Commission Employee");
        Tampil_3102();
        System.out.println("Total Gaji: " + Totalgaji_3102);
    }
}

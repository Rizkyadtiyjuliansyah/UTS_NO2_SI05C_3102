/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no2_c_3102;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author lenovo
 */
public class UTS_NO2_C_3102 {

    public static void main(String[] args) {
        SalariedEmployee_3102 se_3102 = new SalariedEmployee_3102();
        CommissionEmployee_3102 ce_3102 = new CommissionEmployee_3102();
        ProjectPlanner_3102 pp_3102 = new ProjectPlanner_3102();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));        
        try{
            System.out.println("Data Pegawai");
            System.out.print("Nama: ");
            se_3102.Nama_3102 = br.readLine();
            System.out.print("NIP: ");
            se_3102.NIP_3102 = br.readLine();
            System.out.print("Gaji Pokok: ");
            se_3102.GajiPokok_3102 = Float.parseFloat(br.readLine());
            se_3102.TampilData_3102();
            
            System.out.print("Nama: ");
            ce_3102.Nama_3102 = br.readLine();
            System.out.print("NIP: ");
            ce_3102.NIP_3102 = br.readLine();
            System.out.print("GajiPokok: ");
            ce_3102.GajiPokok_3102 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            ce_3102.Komisi_3102 = Float.parseFloat(br.readLine());
            System.out.print("Total Penjualan: ");
            ce_3102.TotalPenjualan_3102 = Float.parseFloat(br.readLine());
            ce_3102.TotalGaji_3102();
            ce_3102.TampilData_3102();
            
            System.out.print("Nama: ");
            pp_3102.Nama_3102 = br.readLine();
            System.out.print("NIP: ");
            pp_3102.NIP_3102 = br.readLine();
            System.out.print("Gaji Pokok: ");
            pp_3102.GajiPokok_3102 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            pp_3102.Komisi_3102 = Float.parseFloat(br.readLine());
            System.out.print("Total Hasil Proyek: ");
            pp_3102.TotalHslProyek_3102 = Float.parseFloat(br.readLine());
            pp_3102.TotalGaji_3102();
            pp_3102.TampilData_3102();
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
}

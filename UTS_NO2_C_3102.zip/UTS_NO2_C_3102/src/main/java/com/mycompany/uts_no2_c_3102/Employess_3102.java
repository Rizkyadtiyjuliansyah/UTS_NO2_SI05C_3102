/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3102;

/**
 *
 * @author lenovo
 */
public class Employess_3102{
    
    protected String Nama_3102;
    protected String NIP_3102;
    protected float GajiPokok_3102;
    
    public void Tampil_3102(){
        System.out.println("Nama: " + Nama_3102);
        System.out.println("NIP: " + NIP_3102);
        System.out.println("Gaji Pokok: " + GajiPokok_3102);
    }
}

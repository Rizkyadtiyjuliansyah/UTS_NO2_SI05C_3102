/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3102;

/**
 *
 * @author badnoby
 */
public class SalariedEmployee_3102 extends Employess_3102 {
    public SalariedEmployee_3102(){
        
    }
    
    public void TampilData_3102(){
        System.out.println("Salaried Employee");
        Tampil_3102();
        System.out.println("Total Gaji: " + GajiPokok_3102);
    }
}
